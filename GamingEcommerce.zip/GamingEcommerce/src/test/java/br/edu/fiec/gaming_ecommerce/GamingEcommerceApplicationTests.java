package br.edu.fiec.gaming_ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamingEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
