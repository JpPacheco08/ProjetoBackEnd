package br.edu.fiec.gaming_ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamingEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamingEcommerceApplication.class, args);
	}

}
